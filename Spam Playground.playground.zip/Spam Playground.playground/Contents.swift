/*:
 # By the Author
 It is a high pleasure of you seeing this playground, I haven't really mastered Programmatic UI like this but its kinda fun
 # Here are the instructions on how to get started using them:
 **1.** Run the code
 **2.** Enter the word to spam
 **3.** Enter how many times to spam
 **4.** Voilla -> Your result is shown in the Text View
 # How to run the code written below
 To run the code, open the assistant editor and click the run button.
 # How did I get inspiration to make this type of project
 Well, I made an app similar to this but only it uses storyboards. This is technically the first time I made a complete project file with Programmatic UI.
 */

/*:
 
 # What is the point of this project
 The point is to show what you can make with playgrounds in xcode (mac) or Swift Playgrounds in the iPad
 I also made this for a youtube video in CS Club.
 I will be posting this in github as well
 */
/*:
 # Why did I want to make all from Programmatic UI
 Well, the reason is that programmatic UI is kinda a new experience for me, especially when it comes to a NO STORYBOARD case and this is like the newest thing I've ever done becuase normally I would be writing IBOutlets and Actions, but now I have to work with hundreds of lines of code and this is fun to me because it helps me feel like I am at the brink of becoming a professional developer
 
 # Where can I run this
 Well running this is possible on a mac (I am not that sure on iPads), however, I have also the xcproject file in case you want the app version
 
 */

/*:
 # WARNING: You do need to change some code with more modules inside though
 If you want to import more stuff then do it below.
 Adding more stuff will allow you for more functionality.
 */
import UIKit
import PlaygroundSupport


/*:
 
 # Frame size
 You can change the frame size of how the screen size will be like.
 
 */
let frame = CGRect(x: 0, y: 0, width: 375, height: 667)

class MyViewController : UIViewController {

    var textView = UITextView()
    let textFieldForNum = UITextField()

    
    let textFieldForText = UITextField()
    
    
   
/*:
# IBActions, but PROGRAMATICALLY!!!
IBActions are what mames up the behaviours of an app, however in programmatic UI, we use the @objc func keyword as well as a sender.
They act like normal @IBActions and will be called in the addToTarget Function
     
     
# IBOutlets, not a big deal
IBOutlets are kinda the thing that changes from actions by the IBActions, here its just a bunch of class declarations.
     
*/
    @objc func spamButtonPressed(sender: UIButton) {
        let numOfTimes : Int = Int(textFieldForNum.text!) ?? 0
        let result = String(repeating: textFieldForText.text!, count: numOfTimes)
        self.textView.text = result
    }
  
    
    
    override func viewDidLoad() {
        let view = UIView()
//: **View's background color property**
        view.backgroundColor = .white
        
        
        
        let label = UILabel()
        
        
        let button = UIButton()
        
/*:
         
# UITextView's properties
         
         
We refer the textview as the place where the spam result will come out
Change the attributes according to your needs
*/
        textView.frame = CGRect(x: 67, y: 215, width: 241, height: 128)
        textView.text = "Result here"
        textView.isEditable = false
        textView.isSelectable = true
        view.addSubview(textView)
        
/*:
         
# TextfieldFor Number Properties
As the name suggests, this is used for how many times the word will be repeated
Change the attributes to your needs
         
         
*/
        textFieldForNum.frame = CGRect(x: 67, y: 126, width: 241, height: 30)
        textFieldForNum.placeholder = "Number of times"
        view.addSubview(textFieldForNum)
        
/*:
# Label's properties
         
Properties of the label "SPAM!"

         
*/
        label.frame = CGRect(x: 107, y: 20, width: 161, height: 71)
        label.text = "SPAM!"
        label.textColor = UIColor.black
        label.font = UIFont(name: "Noteworthy", size: 40.0)
        view.addSubview(label)
/*:
         
# Button Properties
The spam button properties
 */
        button.frame = CGRect(x: 167, y: 177, width: 41, height: 30)
        button.setTitle("SPAM", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        button.titleLabel?.textColor = UIColor.blue
        button.backgroundColor = UIColor.black
        button.addTarget(self, action: #selector(spamButtonPressed(sender:)) ,for: .touchUpInside)
        view.addSubview(button)
        textFieldForText.frame = CGRect(x: 67, y: 88, width: 241, height: 30)
        textFieldForText.placeholder = "Enter the text"
        view.addSubview(textFieldForText)
        
        
        self.view = view
    }
    
}

/*:
 # Running the code in live view
 After all these code, we get to finally run and see our results.
 We need to make sure that we conform to the frame size we chose and made sure that the class it is running is the ViewController class
 Theres nothing to change here, and mind not to touch anything here
 
 */
let vc = MyViewController()
vc.preferredContentSize = frame.size
PlaygroundPage.current.liveView = vc

